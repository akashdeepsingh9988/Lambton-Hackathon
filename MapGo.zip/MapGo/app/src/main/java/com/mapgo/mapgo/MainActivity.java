package com.mapgo.mapgo;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    String subject, date, time, location, description;
    ListView list;

    ArrayList<String> sub = new ArrayList<>();
    ArrayList<String> dt = new ArrayList<>();
    ArrayList<String> loc = new ArrayList<>();
    ArrayList<String> desc = new ArrayList<>();

    Intent intent;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list=(ListView)findViewById(R.id.listView);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), AddNoteActivity.class);
                startActivity(intent);

            }
        });


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                // TODO Auto-generated method stub
                TextView textView = (TextView) view.findViewById(R.id.location);
                TextView textView2 = (TextView) view.findViewById(R.id.count);
                intent = new Intent(getApplicationContext(), MapsActivity.class);
                if(position == 0) {
                    String text = textView.getText().toString();
                    String text2 = textView2.getText().toString();
                    intent.putExtra("location", text);
                    intent.putExtra("subject", text2);
                    Toast.makeText(getApplicationContext(), text,Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }

                else if(position == 1) {
                    String text = textView.getText().toString();
                    String text2 = textView2.getText().toString();
                    intent.putExtra("location", text);
                    intent.putExtra("subject", text2);
                    Toast.makeText(getApplicationContext(), text,Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }

                else if(position == 2) {
                    String text = textView.getText().toString();
                    String text2 = textView2.getText().toString();
                    intent.putExtra("location", text);
                    intent.putExtra("subject", text2);
                    Toast.makeText(getApplicationContext(), text,Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }
                else if(position == 3) {
                    String text = textView.getText().toString();
                    String text2 = textView2.getText().toString();
                    intent.putExtra("location", text);
                    intent.putExtra("subject", text2);
                    Toast.makeText(getApplicationContext(), text,Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }
                else if(position == 4) {
                    String text = textView.getText().toString();
                    String text2 = textView2.getText().toString();
                    intent.putExtra("location", text);
                    intent.putExtra("subject", text2);
                    Toast.makeText(getApplicationContext(), text,Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }

            }
        });

        GetNotes notes = new GetNotes();
        notes.execute();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_add) {
            startActivity(new Intent(getApplicationContext(), AddNoteActivity.class));
            // Handle the camera action
        } else if (id == R.id.nav_about) {
            startActivity(new Intent(getApplicationContext(), AboutActivity.class));

        } else if (id == R.id.nav_contact) {
            startActivity(new Intent(getApplicationContext(), ContactActivity.class));

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.view_appointments) {
            startActivity(new Intent(getApplicationContext(), ViewMeetingsActivity.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private class GetNotes extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
//            Toast.makeText(MainActivity.this,"Json Data is  downloading",Toast.LENGTH_LONG).show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String url = "https://openxdev.com/notes.jsp";
            String jsonStr = sh.makeServiceCall(url);
            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    JSONArray contacts = jsonObj.getJSONArray("events");
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);
                        subject = c.getString("subject");
                        date = c.getString("date");
                        time = c.getString("time");
                        location = c.getString("location");
                        description = c.getString("description");

                        sub.add(subject);
                        loc.add(location);
                        dt.add(date);
                        desc.add(description);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            MyListAdapter adapter = new MyListAdapter(MainActivity.this, sub, dt, loc, desc);
                            list.setAdapter(adapter);
                        }
                    });


                } catch (final JSONException e) {
                    //Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }

            } else {
                //Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

        }
    }
}






