package com.mapgo.mapgo;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class LauncherActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        Loading n = new Loading();
        n.start();
    }

    class Loading extends Thread
    {
        public void run() {
            try {
                Thread.sleep(3000);
                finish();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    }
