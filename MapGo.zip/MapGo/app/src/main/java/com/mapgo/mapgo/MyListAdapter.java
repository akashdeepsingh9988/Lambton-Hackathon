package com.mapgo.mapgo;

import android.app.Activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyListAdapter extends ArrayAdapter<String> {

    private  Activity context;
    private ArrayList <String> subject = new ArrayList<>();
    private ArrayList <String> date = new ArrayList<>();
    private ArrayList <String> location = new ArrayList<>();
    private ArrayList <String> description = new ArrayList<>();


    public MyListAdapter(Activity context, ArrayList<String> subject, ArrayList <String> date, ArrayList<String> location,
                         ArrayList<String> description  ) {
        super(context, R.layout.cards, subject);
        // TODO Auto-generated constructor stub

        this.context = context;
        this.location =  location;
        this.date = date;
        this.subject = subject;
        this.description = description;

    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.cards, null,true);

        TextView titleText = (TextView) rowView.findViewById(R.id.title);
       // ImageView imageView = (ImageView) rowView.findViewById(R.id.thumbnail);
        TextView subtitleText = (TextView) rowView.findViewById(R.id.count);
        TextView desc = (TextView) rowView.findViewById(R.id.description);
        TextView loc = (TextView) rowView.findViewById(R.id.location);

        titleText.setText(date.get(position).replace("[", "").replace("\\", " ").replace("]", "").replace('"', ' '));
        //imageView.setImageResource([position]);
        subtitleText.setText(subject.get(position).replace("[", "").replace("]", "").replace('"', ' '));
        desc.setText(description.get(position).replace("[", "").replace("]", ""));
        loc.setText("Meeting at : "+ location.get(position).replace("[", "").replace("]", "").replace('"', ' '));

        return rowView;

    };
}
