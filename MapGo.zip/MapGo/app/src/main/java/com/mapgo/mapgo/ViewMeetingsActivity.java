package com.mapgo.mapgo;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ViewMeetingsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    String subject, date, time, location, description;
    ListView list;
    Context context;
    String lat, lan;

    ArrayList<String> sub = new ArrayList<>();
    ArrayList<String> dt = new ArrayList<>();
    ArrayList<String> loc = new ArrayList<>();
    ArrayList<String> desc = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_meetings);
        new GetNotes().execute();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        context = getApplicationContext();

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;
        Address location;
        LatLng syd;
        Log.d("loc data", loc.toString());
        try {
            // May throw an IOException
            {
                address = coder.getFromLocationName("lambton college toronto", 5);
                location = address.get(0);
                p1 = new LatLng(location.getLatitude(), location.getLongitude() );
                lat = String.valueOf(p1.latitude);
                lan =  String.valueOf(p1.longitude);
                syd = new LatLng(Double.parseDouble(lat), Double.parseDouble(lan));
                mMap.addMarker(new MarkerOptions().position(syd).title("Lambton College Toronto"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(syd));

                address = coder.getFromLocationName("lambton College", 5);
                location = address.get(0);
                p1 = new LatLng(location.getLatitude(), location.getLongitude() );
                lat = String.valueOf(p1.latitude);
                lan =  String.valueOf(p1.longitude);
                syd = new LatLng(Double.parseDouble(lat), Double.parseDouble(lan));
                mMap.addMarker(new MarkerOptions().position(syd).title("Lambton College"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(syd));

                address = coder.getFromLocationName("Brampton", 5);
                location = address.get(0);
                p1 = new LatLng(location.getLatitude(), location.getLongitude() );
                lat = String.valueOf(p1.latitude);
                lan =  String.valueOf(p1.longitude);
                syd = new LatLng(Double.parseDouble(lat), Double.parseDouble(lan));
                mMap.addMarker(new MarkerOptions().position(syd).title("Brampton"));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(syd));
            }

            //Toast.makeText(getApplicationContext(), lat+lan, Toast.LENGTH_LONG).show();

        } catch (IOException ex) {

            ex.printStackTrace();
        }
        // Add a marker in Sydney and move the camera
    }

    private class GetNotes extends AsyncTask<Void, Void, Void> {
        ProgressDialog pdLoading = new ProgressDialog(ViewMeetingsActivity.this);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

//            Toast.makeText(MainActivity.this,"Json Data is  downloading",Toast.LENGTH_LONG).show();
        }
        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String url = "https://openxdev.com/notes.jsp";
            String jsonStr = sh.makeServiceCall(url);
            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    JSONArray contacts = jsonObj.getJSONArray("events");
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);
                        subject = c.getString("subject");
                        date = c.getString("date");
                        time = c.getString("time");
                        location = c.getString("location");
                        description = c.getString("description");
                        sub.add(subject);
                        loc.add(location);
                        dt.add(date);
                        desc.add(description);
                        Log.d("locd",loc.toString());
                    }

                } catch (final JSONException e) {
                    //Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }

            } else {
                //Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
           // pdLoading.dismiss();

        }
    }


}
